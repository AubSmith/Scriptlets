# Introduction

In lexicographic/alphabetical order, this file lists authors and
contributors to the project.  It is meant to recognize and credit their
contributions to the project.

Introduction of names in this file is completely voluntary, as some people
may not want to be included given their potential employment requirements or
other issues. We respect the contributor's wishes.

To be included in this file, just send a pull request with your name, once
you have at least one contribution to the project.

# Contributors

* Emad Shaaban
* George Monkey
* Ismaël Mejía
* Rogério Theodoro de Brito
