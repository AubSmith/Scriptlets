import org.apache.commons.lang3.StringUtils;

/**
 * Created by jt on 2018-11-26.
 */
public class HelloWorld {

    public static void main(String[] args) {
        System.out.println("Hello World!!!! ");
        System.out.println(StringUtils.capitalize("hello world"));
    }
}
