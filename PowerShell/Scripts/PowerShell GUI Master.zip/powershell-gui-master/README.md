# powershell-gui
Creating a GUI in powershell
For details on this project and similar post please visit  my blog https://gigadom.wordpress.com/
