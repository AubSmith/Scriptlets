﻿
function global:functionName {}

function functionTwo {}
