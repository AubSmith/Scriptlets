﻿
# not a violation of the rule since this is not a module
function global:functionName {}

function functionTwo {}
