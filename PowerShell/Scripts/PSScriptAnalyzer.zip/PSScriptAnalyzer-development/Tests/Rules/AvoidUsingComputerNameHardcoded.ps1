﻿Invoke-Command -Port 343 -ComputerName "hardcode1"
Invoke-Command -ComputerName:"hardcode2"