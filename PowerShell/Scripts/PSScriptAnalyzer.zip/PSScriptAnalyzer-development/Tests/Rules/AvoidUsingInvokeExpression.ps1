﻿Invoke-Expression "Invoke me"
iex "Invoke me"