﻿Get-ChildItem D:\Code
Write-Warning "E:\Code"
Get-ChildItem \\scratch2\scratch\
Get-ChildItem ..\Test
Write-Warning 'C:\DD'
Write-Warning "Random string"
Write-Verbose "lol look at C:\ddd"