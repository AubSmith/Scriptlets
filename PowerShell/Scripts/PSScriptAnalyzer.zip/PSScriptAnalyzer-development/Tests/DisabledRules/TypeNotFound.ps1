﻿function Get-File ([Stre]$test) {
	[Stt]$a = 3
}

$directory = Split-Path -Parent $MyInvocation.MyCommand.Path