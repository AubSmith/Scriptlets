# MisleadingBacktick

**Severity Level: Warning**

## Description

Checks that lines don't end with a backtick followed by whitespace.